﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail; //biblioteca para email

namespace AppMail
{
    public partial class FormMail : Form
    {
        public FormMail()
        {
            InitializeComponent();
        }

        public void SendMail() //criar essa public
        {
            System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
            message.To.Add(txtPara.Text); //para adicionar
            message.CC.Add(txtCc.Text);
            System.Net.Mail.Attachment anexo = new System.Net.Mail.Attachment(txtAnexo.Text); //Chama, da um nome e avisa quem vai mandar o anexo, no caso txt
            message.Attachments.Add(anexo); //menssagem, anexa.
            message.Subject = txtAssunto.Text; //assunto (subject) já é uma string, nao precisa colocar Add
            message.From = new System.Net.Mail.MailAddress("alissonc_andre@hotmail.com");
            message.Body = txtMensagem.Text; //body ja é tratado com string
            System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient(); //Protocolo para enviar email
            smtp.Host = "smtp.office365.com"; //quem vai receber nosso email
            smtp.EnableSsl = true;   //segurança -rotina de segurança de email
            smtp.Port = 587; //foi colocada essa porta para pode funcionar, testar sem
            message.Priority = MailPriority.High; // foge da fila de email, prioridade alta
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new System.Net.NetworkCredential("alissonc_andre@hotmail.com", "alissonc15"); //para colocar login e senha
            try
            {
                smtp.Send(message);
                MessageBox.Show("E-mail enviado com sucesso!");
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message); 
            }
        }
        //apos aqui, começar os botoes
        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            SendMail();
        }

        private void btnAnexo_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            txtAnexo.Text = openFileDialog1.FileName;
        }
    }
}
